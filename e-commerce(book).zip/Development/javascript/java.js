

function validateform() {
    var name = document.forms["Hello"]["name"].value;
    var email = document.forms["Hello"]["email"].value;
    var contact = document.forms["Hello"]["contact"].value;
    var message = document.forms["Hello"]["Message"].value;

    if (name == "" || email == "" || message == "" || contact == "") {
        alert("All fields are required");
    }
    else {
        alert("Thank you for your feedback.");
    }


}
